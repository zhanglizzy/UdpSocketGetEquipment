//
//  AppDelegate.h
//  UdpSocketGetEquipment
//
//  Created by lizzy on 17/4/14.
//  Copyright © 2017年 lizzy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

