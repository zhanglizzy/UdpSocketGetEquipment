//
//  main.m
//  UdpSocketGetEquipment
//
//  Created by lizzy on 17/4/14.
//  Copyright © 2017年 lizzy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
